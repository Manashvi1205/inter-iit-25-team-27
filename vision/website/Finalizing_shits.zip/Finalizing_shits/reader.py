def read(img):
    pass